# columnwise input
A <- matrix(c(2,-1,3,0,1,4), ncol = 3)
# rowwise input
A <- matrix(c(2, 3, 1, -1, 0, 4), ncol = 3, byrow = TRUE)
# display A
A


# We can obtain these dimensions in R using the following:
dim(A) 
nrow(A)
ncol(A) 


# We can easily create vectors in R
v1 = matrix(c(1,3,5), ncol = 1)
v1

v2 = matrix(c(2,4,6), nrow = 1)
v2

# The transpose of our 2 x 3 matrix is
t(A)

# Matrix of zeros
matrix(0, nrow = 2, ncol = 3)

diag(c(1,3,5))