# The Mahalanobis Method (6 of 8)
# Consider a set of 200 human heights and weight measurements from a 1993 survey.

urlRemote <- "https://raw.githubusercontent.com/"
pathGithub <- "EricBrownTTU/ISQS6350/main/"
filename <- "HeightWeight.csv" 

hw <- read.csv(paste0(urlRemote, pathGithub, filename))
head(hw)
#Height  Weight
#1	65.78    112.99
#2	71.52    136.49
#3	69.40    153.03
#4	68.22    142.34
#5	67.79    144.30
#6	68.70    123.30

xbar <- colMeans(hw) 
S <- cov(hw)

# computer the Mahalanobis distance for all observations
# iterate over rows using apply() 
d2 <- mahalanobis(hw, xbar, S) 

round(head(d2),4)
#[1] 1.7167 3.4759 4.9546 2.0596 3.1547 0.5772

# create histogram
hist(d2)

# Now we can identify as outliers those observations who, according to the chi-square distribution, have a likelihood of less than 10%
# Then we can identify them in a plot
out <- which(1 - pchisq(d2, 2) < .1)
plot(hw$Height, hw$Weight, xlab = "Height", ylab = "Weight") 
points(hw$Height[out], hw$Weight[out], col = "red", pch = 19)