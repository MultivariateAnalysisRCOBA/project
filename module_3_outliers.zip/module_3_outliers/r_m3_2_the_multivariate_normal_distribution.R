# The Multivariate Normal Distribution (2 of 5)
# * If a random variable X with mean µ and variance σ2, the density is given by
# * This function is represented by the familiar bell-shaped curve

#R code:
x <- seq(-5,25,0.01)
plot(x, dnorm(x,10,2.5), type = "l")


library(mnormt) 
x <- seq(-3,3,0.1) 
y <- seq(-3,3,0.1)
mu <- c(0,0) 
sigma <- matrix(c(2,-1,-1,2), nrow = 2) 
f <- function(x,y) dmnorm(cbind(x,y), mu, sigma) 
z <- outer(x,y,f)
persp(x,y,z, theta=30, expand = 0.6, ticktype = "detailed")