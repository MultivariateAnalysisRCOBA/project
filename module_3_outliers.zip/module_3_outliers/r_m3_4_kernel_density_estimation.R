# Kernel Density Estimation (1 of 16)
# A classical method to represent data graphically is the histogram.
# Consider the “Old Faithful” dataset, built into R. Let’s construct a histogram of the time between eruptions.

hist(faithful$waiting, main = "Histogram of the Old Faithful Dataset", xlab = "Wait Time Between Eruptions", freq = FALSE)

# Kernel Density Estimation (4 of 16)
# Consider a histogram of bins of equal width. In this case, the bins can be characterized of the form:
# Bi = (r + (i − 1)b,r + ib]	  for i = 1,2,...,m
# where r is some reference point smaller than the minimum of the dataset, and b denotes the bin width.

# Consider the following three choices of bin width
b1 <- (max(faithful$waiting) - min(faithful$waiting)) 
b2 <- (max(faithful$waiting) - min(faithful$waiting)) / 5 
b3 <- (max(faithful$waiting) - min(faithful$waiting)) / 18

hist(faithful$waiting, breaks = b1, main = "Bin width 2", xlab = "Wait Time", freq = FALSE)
hist(faithful$waiting, breaks = b2, main = "Bin width 5", xlab = "Wait Time", freq = FALSE)
hist(faithful$waiting, breaks = b3, main = "Bin width 18", xlab = "Wait Time", freq = FALSE)


# Kernel Density Estimation (5 of 16)
# •	These bin widths are approximately 2, 5, and 18, respectively.
# •	Clearly, the choice of bin width has a substantial effect on the resulting histogram.
# •	Too small bin width results in too much noise, too large a bin width results in insufficient information.

# Kernel Density Estimation (7 of 16)
# •	We can graphically represent data in a setting which seeks this advantage in the form of a kernel density estimate.
# •	Consider the following figure.
plot(density(faithful$waiting), 
main = "Kernel Density Estimate of the Old Faithful Data", 
xlab = "Wait Time Between Eruptions")


# Kernel Density Estimation (8 of 16)
# •	Similar to the histogram, the kernel density estimate reveals the asymmetry in the data, but it is now much smoother than the histogram.
# •	In addition, it is now much easier to estimate the two typical values around which the elements accumulate.
# •	The idea behind the construction of the kernel density estimate is to “put a pile of sand” around each observation in the dataset.
# •	At places where elements accumulate, the sand will pile up.

# Kernel Density Estimation (10 of 16)
# •	The four most common kernels are Gaussian (normal), triangualr, the Epanechnikov kernel, and rectangular kernel. We can see them below.
plot(density(c(0,0), kernel = "gaussian"))
plot(density(c(0,0), kernel = "triangular")) 
plot(density(c(0,0), kernel = "epanechnikov")) 
plot(density(c(0,0), kernel = "rectangular"))

# Kernel Density Estimation (11 of 16)
# •	Now we can see what the four kernels would result in on our old faithful dataset.
plot(density(faithful$waiting, kernel = "gaussian")) 
plot(density(faithful$waiting, kernel = "triangular")) 
plot(density(faithful$waiting, kernel = "epanechnikov")) 
plot(density(faithful$waiting, kernel = "rectangular"))



# Kernel Density Estimation (12 of 16)
# •	As we can see from the previous slide, the density estimate is largely the same regardless of kernel choice. What is particularly impactful is the choice of bandwidth.
# •	The bandwidth plays the same role in density estimation as the bin width does in the histogram.
# •	Let’s plot using our triangular kernel with different bandwidths.
plot(density(faithful$waiting, kernel = "triangular", bw = 1)) 
plot(density(faithful$waiting, kernel = "triangular", bw = 5)) 
plot(density(faithful$waiting, kernel = "triangular", bw = 18))




# Kernel Density Estimation (13 of 16)
# •	It’s clear that the choice of bandwidth is extremely impactful in the final density estimate.
# •	Too small of bandwidth creates too much noise, too large loses information.
# •	How does one go about choosing bandwidth? Research has provided some useful guidelines for a data-based choice of h. A formula that has proven effective is:
  # h = 1.06sn −1/5
# where s is the sample standard deviation of the data.




# Kernel Density Estimation (14 of 16)
# •	Let’s do a brief example to solidify our understanding. Consider some made up data.
x <- c(0, 1, 1.1, 1.5, 1.9, 2.8, 2.9, 3.5) 
hist(x, main = "Histogram of Made-Up Data", freq = FALSE)




# Kernel Density Estimation (15 of 16)
# •	Let’s start by making a fine grid starting below the minimum of our data and ending above the max. Then we can use dnorm() to simulate a normal kernel. 
x <- c(0, 1, 1.1, 1.5, 1.9, 2.8, 2.9, 3.5);
# create grid of points
xgrid <- seq(from = min(x) - 1,to = max(x) + 1, by = 0.001)
# h determines the bandwidth 
h <- 0.4
# make bumps with gaussian denesity function
bumps<-sapply(x, function(x) (1/n*h)*dnorm((xgrid-x)/h, mean=0, sd=1))




# Kernel Density Estimation (16 of 16)
# •	We can now make our density plot
plot(xgrid, rowSums(bumps), 
     ylab = "f(x)", 
     type = "n", xlab = "n",
     main="GAUSSIAN BUMPS SUMMED, using KERNEL DENSITY f") 
out <- apply(bumps,2,function(b) lines(xgrid, b)) 
rug(x, lwd = 2) 
lines(xgrid, rowSums(bumps), lwd = 2)