# 5 Kernel Density Outlier Detection
# Kernel Density Outlier Detection (1 of 4)
# •	We can use the ks package and the kde command to execute multivariate kernel density estimation
# •	There are many approaches to answering the question, “In terms of density, what constitutes an outlier?”
# •	If you are interested, read up on local outlier factor (LOF) and local density factors (LDF)
# •	For us, let’s keep it simple

# Kernel Density Outlier Detection (2 of 4)
# •	We can use the kde function in the ks package to conduct multivariate kernel density estimation
# •	I’m going to use the eval.points argument to evaluate each of the points in the dataset, otherwise you get a grid of points

urlRemote <- "https://raw.githubusercontent.com/" 
pathGithub <- "EricBrownTTU/ISQS6350/main/" 
filename <- "HeightWeight.csv"

hw <- read.csv(paste0(urlRemote, pathGithub, filename))

hw.kde <- kde(hw, eval.points = hw)

# Kernel Density Outlier Detection (3 of 4)
# •	Reminder: lower densities imply points in areas where there are few other points
# •	So we want to inspect the points corresponding to the lowest density
# •	We can use the quantile function to identify a pre-specified proportion of the points corresponding to the smallest density values
# •	Let’s look at the smallest 5%

out <- which(hw.kde$estimate <= quantile(hw.kde$estimate, .05)) 
out
# 3 23 31 98 104 110 139 157 175 190


# Kernel Density Outlier Detection (4 of 4)
# •	Now, we can plot our data again and see which points are identified as outliers.

plot(hw$Height, hw$Weight, xlab = "Height", ylab = "Weight") 
points(hw$Height[out], hw$Weight[out], col = "red", pch = 19)