#Metric MDS – Derivation (4 of 10)

library(MASS)
x <- mvrnorm(5, 1:5, diag(5))
d <- dist(x, diag = TRUE, upper = TRUE)
a <- as.matrix((-1/2) * dˆ2)
h <- diag(5) - ((1/5) * matrix(1,5,1) %*% matrix(1,1,5))

b1 <- h %*% a %*% h
b1

b2 <- (h %*% x) %*% t(h %*% x)
b2

b3 <- scale(x, scale = FALSE) %*% t(scale(x, scale = FALSE))
b3


#How do we construct, using only the information in B, a set of 5 points
#that have the same Euclidean distances as shown in D?
#First, we need to compute the spectral decomposition of B. For this,
#let’s use R.

b <- matrix(c(0,0,0,0,0,
              0,1,00,-1,0,
              0,0,1,0,-1,
              0,-1,0,1,0,
              0,0,-1,0,1),
            nrow = 5, byrow = TRUE)
eigen(b)$values
#[1] 2.000000e+00 2.000000e+00 1.110223e-15 1.110223e-15 0.000000e+00\

eigen(b)$vectors[,1:2]




#We can now compute the coordinates of five points in two dimensions
#which have the same distance matrix as given by D.

b.eig$vectors[,1:2] %*% diag(sqrt(b.eig$values[1:2]))

#[,1] [,2]
#[1,] 0 0
#[2,] 0 -1
#[3,] -1 0
#[4,] 0 1
#[5,] 1 0

dist(b.eig$vectors[,1:2] %*% diag(sqrt(b.eig$values[1:2])),
     upper = TRUE, diag = TRUE)



#Now for the less painful version, we use the cmdscale() function in R
#to facilitate.
#Note that cmdscale() uses the distance matrix as input and returns
#the points. You can also specify the number of dimensions you prefer.

x <- matrix(c(0,0,1,0,0,1,-1,0,0,-1), nrow = 5, byrow = TRUE)
d <- dist(x)
x.cmd <- cmdscale(d)
dist(x.cmd, diag = TRUE, upper = TRUE)