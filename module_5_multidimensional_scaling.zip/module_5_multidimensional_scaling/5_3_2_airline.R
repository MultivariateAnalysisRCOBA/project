# Let’s do a nice illustration of MDS using some geographic data.
# Consider the following data which consists of airline distances between
# pairs of US cities.

urlRemote <- "https://raw.githubusercontent.com/"
pathGithub <- "EricBrownTTU/ISQS6350/main/"
filename <- "airline_distance.csv"

airline <- read.csv(paste0(urlRemote, pathGithub, filename))
airline[1:5,1:5]

# Since the cities naturally lie in a two-dimensional space (let’s ignore the
# curvature of the earth), we might hope that MDS in 2 dimensions will
# plot these cities appropriately.

airline.mds <- cmdscale(airline, eig = TRUE)
plot(airline.mds$points, type = "n",
     xlab = "1st component", ylab = "2nd component",
     main = "MDS of Airline Data")
text(airline.mds$points, labels = colnames(airline))

# It looks like both of our axes are flipped. As we know from previous
# discussions, the sign on the eigenvectors is arbitrary, so we can flip these
# axes.

plot(-airline.mds$points, type = "n",
     xlab = "1st component", ylab = "2nd component",
     main = "MDS of Airline Data -- Axes Flipped")
text(-airline.mds$points, labels = colnames(airline))