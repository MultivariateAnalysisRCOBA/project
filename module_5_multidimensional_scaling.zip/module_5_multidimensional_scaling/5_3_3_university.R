# Now consider the university dataset.

urlRemote <- "https://raw.githubusercontent.com/"
pathGithub <- "EricBrownTTU/ISQS6350/main/"
filename <- "university.csv"

university <- read.csv(paste0(urlRemote, pathGithub, filename))
head(university)

# These data show the average SAT score of entering freshman, percent of
# freshman in the top 10% of their graduating class, percent of
# applications selected, student-faculty ratio, estimated annual expense,
# and graduation rate (in %) for 25 top universities

# Let’s conduct multidimensional scaling
# Before we do so, recall that MDS on Euclidean distances is equivalent to
# PCA
# Take a look at the data, should we scale it prior to conducting MDS?




# Let’s conduct MDS on our scaled data
uni.d <- dist(scale(university[,2:7]))
uni.mds <- cmdscale(uni.d)
plot(uni.mds, type = "n", main = "Multidimensional Scaling of University Data", xlab = "1st component", ylab = "2nd component")
text(uni.mds, labels = university[,1], cex = 1.2)

uni.pca <- princomp(scale(university[,2:7]))
uni.pca
summary(uni.pca, loadings = TRUE)



# Component 1: Contrast between (SAT, Top 10%, Cost, Graduation rate) and (Acceptance Rate, Student-Faculty ratio)
# Component 2: Contrast between (Cost) and (Student-Faculty Ratio, Graduation Rate)
# Let’s re-plot using the PCA results to ensure our interpretation is accurate

plot(uni.pca$scores[,1:2], type = "n")
text(uni.pca$scores[,1:2], labels = university[,1])

# cbind(university[,1], round(scale(university[,2:7]),2))