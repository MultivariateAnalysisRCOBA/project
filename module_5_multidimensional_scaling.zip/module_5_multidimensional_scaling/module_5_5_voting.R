# Let’s look at another classical example to demonstrate non-metric MDS
# One way to assess similarity is via voting patterns. Consider the voting
# history of 15 congressmen on environmental legislation.
# The following data shows how many times each pairing of congressmen
# voted differently across 18 pieces of legislation.

library(MASS)
data("voting", package = "HSAUR2")
voting[1:5,1:5]


# We will use the isoMDS() function to execute non-metric MDS
voting.mds <- isoMDS(voting)

# We can see how strong of a fit we obtained by observing the stress value
# next to the text “obtained” above, or with voting.mds$stress
voting.mds$stress

# Let’s plot the results and see what we can learn.
plot(voting.mds$points, type = "n",
     main = "Non-Metric MDS on Voting Data",
     xlab = "Component 1", ylab = "Component 2")
text(voting.mds$points, labels = colnames(voting),
     cex = 1.2)